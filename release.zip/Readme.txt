Howto Build
===========

使用 Flash Builder 4.6 打开项目，运行。